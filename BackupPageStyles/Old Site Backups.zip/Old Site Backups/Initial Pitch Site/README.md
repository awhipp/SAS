Snack Attack
===
Code named the Sassy Antelope.
Feel free to browse. Don't expect to be entertained.
A Site to demonstrate my pitch for improved employee engagement strategies.

###
For my own recollection:

1. alias clone-html='git clone https://github.com/awhipp/sassy.antelope.git html'

2. alias push-html='function _pushhtml(){ git add . && git commit -m "$1" && git push; };_pushhtml'
